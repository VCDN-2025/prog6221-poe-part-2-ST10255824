﻿
using System.Media;


namespace CyberSecurityBot
{
    class Program
    {
        //https://www.geeksforgeeks.org/c-sharp-list-class/
        static List<string> userHistory = new List<string>(); // stores the users previous messages to simulate memory
        static Random random = new Random(); // used to pick random responses

        static void Main(string[] args)
        {
            PlayVoiceGreeting();
            DisplayAsciiArt();
            StartChat();
        }
        ////https://stackoverflow.com/questions/3502311/how-to-play-a-sound-in-c-net
        static void PlayVoiceGreeting()
        {
            try
            {
                using (SoundPlayer player = new SoundPlayer("greeting.wav"))
                {
                    player.PlaySync();
                }
            }
            catch
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Voice greeting could not be played. Make sure 'greeting.wav' is in the correct place and make sure it is under the correct name");
                Console.ResetColor();
            }
        }

        static void DisplayAsciiArt()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
     ___________________________
    |  _______________________  |
    | |                       | |
    | |   CYBERSECURITY BOT   | |
    | |_______________________| |
    |___________________________|
        || ||     ||     || ||
        || ||     ||     || ||
        || ||     ||     || ||
        || ||     ||     || ||
        || ||     ||     || ||
       [__||_____||_____||__]
       |_____________________|

     SECURITY MODE ACTIVATED 
==================================================
");
            Console.ResetColor();
        }

        ////https://www.w3schools.com/cs/cs_user_input.php

        static void StartChat()
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("\nHello there! What's your name? ");
            Console.ResetColor();
            string userName = Console.ReadLine();
            Console.WriteLine();

            // //https://www.w3schools.com/cs/cs_conditions.php
            if (string.IsNullOrWhiteSpace(userName))
            {
                userName = "Cyber General";
            }

            TypingEffect($"Welcome, {userName}! I'm here to help you stay cyber-safe. Ask me anything cybersecurity-related, or type 'help' to see what I know!");

            //https://www.geeksforgeeks.org/c-sharp-dictionary-with-examples/
            Dictionary<string, List<string>> keywordResponses = new Dictionary<string, List<string>>
            {
                ["phishing"] = new List<string> {
                    "That email might be bait. If you're unsure, don't click links.",
                    "Phishing warning: Never give out your credentials unless you're 100% sure.",
                    "Watch out for suspicious emails, especially ones with urgency.",
                    "Think that message is odd? It might be a phishing attempt. Better safe than sorry!"
                },
                ["password"] = new List<string> {
                    "Use a mix of upper/lowercase, numbers, and symbols.",
                    "A good password is like a good secret – unpredictable and safe.",
                    "Don’t reuse old passwords – it’s like locking your door with a rusty key.",
                    "Use a password manager to keep your credentials safe."
                },
                ["vpn"] = new List<string> {
                    "VPN hides your traffic from prying eyes. Good for public WiFi.",
                    "VPN = digital invisibility cloak. Great for staying private.",
                    "Traveling? Use a VPN to keep your data safe overseas.",
                    "VPN reroutes your connection to keep you hidden and secure."
                },
                ["antivirus"] = new List<string> {
                    "An updated antivirus can catch threats before they spread.",
                    "Antivirus software is your digital immune system – keep it strong.",
                    "No antivirus? That’s like walking into battle with no armor.",
                    "Regular scans help keep viruses away."
                },
                ["public wifi"] = new List<string> {
                    "Public WiFi is convenient but risky. Use a VPN when possible.",
                    "Hackers love open networks. Be cautious with sensitive tasks.",
                    "Avoid logging into sensitive accounts on public networks.",
                    "Use your phone's hotspot for better security."
                },
                ["2fa"] = new List<string> {
                    "Two-Factor Authentication adds an extra layer of protection.",
                    "Even if someone gets your password, 2FA blocks them.",
                    "Think of 2FA as a security checkpoint for your accounts.",
                    "Double-lock your digital doors with 2FA."
                },
                ["authentication"] = new List<string> {
                    "Authentication verifies you're the real you.",
                    "Biometric or password? Multi-factor authentication is best.",
                    "Strong authentication keeps intruders out.",
                    "Use authentication apps for better security than SMS."
                },
                ["social media"] = new List<string> {
                    "Be mindful of what you post. It can reveal more than you think.",
                    "Privacy settings are your friend. Use them.",
                    "Avoid sharing personal info like location and vacation plans.",
                    "The internet remembers. Think before you share."
                },
                ["scam emails"] = new List<string> {
                    "Suspicious subject line? Don’t open it.",
                    "Check the sender’s address – is it legit?",
                    "Don’t download attachments from unknown sources.",
                    "If it seems too good to be true, it probably is."
                },
                ["software updates"] = new List<string> {
                    "Updates patch security holes. Don’t ignore them.",
                    "Update early, update often.",
                    "Software updates = security upgrades.",
                    "Clicking ‘remind me later’ isn’t safe in the long run."
                },
                ["cookies"] = new List<string> {
                    "Cookies track your activity – clear them regularly.",
                    "Not all cookies are sweet. Some invade your privacy.",
                    "Customize cookie settings on websites for better control.",
                    "Want privacy? Reject non-essential cookies."
                }
            };

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write($"\n{userName}: ");
                Console.ResetColor();
                string input = Console.ReadLine().ToLower();

                //https://www.geeksforgeeks.org/c-sharp-list-class/
                userHistory.Add(input);

                if (string.IsNullOrWhiteSpace(input))
                {
                    TypingEffect("That was... nothing. Try typing something!");
                }
                else if (input == "help")
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\n========================= ASK ME ABOUT =========================");
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine(" how are you         – Feeling curious?");
                    Console.WriteLine(" what's your purpose – Learn my job.");
                    Console.WriteLine(" passwords           – Tips for secure passwords.");
                    Console.WriteLine(" phishing            – Spot fake emails & scams.");
                    Console.WriteLine(" antivirus           – Keep the baddies away.");
                    Console.WriteLine(" public wifi         – Risky biz in coffee shops.");
                    Console.WriteLine(" vpn                 – Ninja-mode activated.");
                    Console.WriteLine(" 2FA / authentication – Double lock your accounts.");
                    Console.WriteLine(" social media        – Think before you post.");
                    Console.WriteLine(" scam emails         – Recognize & avoid them.");
                    Console.WriteLine(" software updates    – No more 'remind me later'.");
                    Console.WriteLine(" cookies             – They're watching.");
                    Console.WriteLine(" what did I say      – Review your chat history.");
                    Console.WriteLine(" exit / quit / bye   – End the convo.");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("=====================================================================");
                    Console.ResetColor();
                }
                else if (input == "what did i say")
                {
                    TypingEffect("Here's what you've said so far:");
                    foreach (string history in userHistory)
                    {
                        TypingEffect("• " + history);
                    }
                }
                else if (input == "exit" || input == "quit" || input == "bye")
                {
                    TypingEffect("Stay safe out there, " + userName + "! Logging off...");
                    break;
                }
                else
                {
                    bool foundKeyword = false;

                    foreach (var keyword in keywordResponses.Keys)
                    //https://www.geeksforgeeks.org/c-sharp-string-contains-method/
                    {
                        if (input.Contains(keyword))
                        {
                            //https://www.bytehide.com/blog/random-elements-csharp#:~:text=Practical%20Examples%3A%20Retrieving%20Random%20Elements%20From%20Lists,-Say%20you%20have&text=In%20C%23%2C%20you%20would%20do,Next(fruits.
                            List<string> responses = keywordResponses[keyword];

                            if (input.Contains("worried") || input.Contains("afraid") || input.Contains("scared") || input.Contains("nervous") || input.Contains("unsure"))
                            {
                                TypingEffect("It’s okay to feel that way. " + responses[random.Next(responses.Count)]);
                            }
                            else if (input.Contains("thank you") || input.Contains("thanks") || input.Contains("great") || input.Contains("awesome"))
                            {
                                TypingEffect("I’m glad I could help! " + responses[random.Next(responses.Count)]);
                            }
                            else
                            {
                                TypingEffect(responses[random.Next(responses.Count)]);
                            }

                            foundKeyword = true;
                            break;
                        }
                    }
                    //https://www.geeksforgeeks.org/c-sharp-string-contains-method/

                    if (!foundKeyword)
                    {
                        if (input.Contains("worried") || input.Contains("afraid") || input.Contains("scared") || input.Contains("nervous") || input.Contains("unsure"))
                        {
                            TypingEffect("I sense some worry. Cybersecurity can feel overwhelming, but you’re not alone!");
                        }
                        else if (input.Contains("thank you") || input.Contains("thanks") || input.Contains("great") || input.Contains("awesome"))
                        {
                            TypingEffect("Always happy to help! Stay secure!");
                        }
                        else
                        {
                            string[] randomResponses = {
                                "I didn’t quite catch that. Type 'help' to see what I can help with.",
                                "I'm still learning! Try rephrasing your question.",
                                "That's beyond my current firewall! Type 'help' for topics I understand."
                            };
                            TypingEffect(randomResponses[random.Next(randomResponses.Length)]);
                        }
                    }
                }
            }
        }


        // //https://krutarthpurohit.medium.com/different-ways-to-provide-time-delays-in-c-program-df4cc849b19b
        static void TypingEffect(string message, int delay = 30)
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(delay);
            }
            Console.WriteLine();
            Console.ResetColor();
        }
    }
}



